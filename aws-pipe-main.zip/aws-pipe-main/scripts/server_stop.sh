#!/bin/bash
sudo chmod +x /home/ec2-user/tomcat/bin/./shutdown.sh
sudo /home/ec2-user/tomcat/bin/./shutdown.sh
